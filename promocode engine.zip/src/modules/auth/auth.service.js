const loginService = async (email, password) => {};

const signupService = async ({username,email, password}) => {};

const authService = {
  loginService,
  signupService,
};

export default authService

import authService from "./auth.service.js"

export const loginController = async(req,res) => {
    const {email,password} = req.body

    const result = await authService.loginService(email,password)
    
}
export const signupController = async(req,res) => {}
import express from 'express'
import { errorHandler } from './middlewares/errorHandler.js'
import "./infrastructure/db/index.js"
import authRoutes from "./modules/auth/auth.routes.js"

const app = express()

app.use("/api/auth",authRoutes)
app.use(errorHandler)
export default app
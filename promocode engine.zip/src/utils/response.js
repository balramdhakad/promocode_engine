const sendResponse = (
  res,
  { statusCode = 200, message = null, data = null },
) => {
  const response = { success: true };
  if (data) response.data;
  if (message) response.message;

  res.status(statusCode).json(response);
};

const sendResponseWithPagination = (res, { data, pagination }) => {
  const { page = 1, limit = 10, total = 1 } = pagination;
  res.statusCode(200).json({
    success: true,
    data,
    pagination: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page < totalPages,
      hasPrev: page > 1,
    },
  });
};
